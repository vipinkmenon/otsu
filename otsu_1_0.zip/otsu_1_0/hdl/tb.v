`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03.09.2026 21:39:52
// Design Name: 
// Module Name: tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`define imageSize 65536

module tb(

    );
    
reg clk;
reg aresetn;
reg [31:0] rxData [511:0];

initial
begin
    clk = 0;
    forever
    begin
        clk <= !clk;
        #5;
    end
end


initial
begin
    aresetn = 0;
    #200;
    @(posedge clk)
    aresetn <= 1;
end    

reg [31:0] imgData;
reg tvalid;
integer sentSize;
integer file;
integer file1;
integer i;
reg sendImg = 0;
wire [31:0] m_axis_data;
real mu0;
real mu1;
real max_sigma;
real sigma_b;
integer otsu_threshold;
integer sum0;
integer sum1;
integer total_weight;
integer w0;
integer w1;
reg storeImg;

initial
begin
    
    sendImg = 1;
end


initial
 begin
    sentSize = 0;
	tvalid = 0;
	storeImg = 0;
	@(posedge aresetn);
    #100;
    writeAxi(0,0); //assert soft reset
    #100;
    writeAxi(8,`imageSize); //store image size
    #100;
    writeAxi(0,1); //remove reset (start)
    file = $fopen("image.bin","rb");  
    for(i=0;i<`imageSize/4;i=i+1) //send image
    begin
        @(posedge clk);
        #1;
        $fscanf(file,"%c%c%c%c",imgData[7:0],imgData[15:8],imgData[23:16],imgData[31:24]); //32 bit data
        tvalid <= 1'b1;
        sentSize = sentSize + 1;
    end  
    $fclose(file);
    @(posedge clk);
    tvalid <= 1'b0;
	@(posedge intr);
	#100;
	$display("Got Interrupt");
	$display("Cumulative Histogram");
	for(i=0;i<256;i=i+1)
     begin
		$display("%d  %d",i,rxData[i]);
	end
	$display("Cumulative Weighted Histogram");
	for(i=0;i<256;i=i+1)
     begin
		$display("%d  %d",i,rxData[256+i]);
	end
	max_sigma = -1;
	total_weight = rxData[511];
	for(i=0;i<256;i=i+1)  //calculate threshold
	begin
		w0 = rxData[i];
		w1 = `imageSize - w0;
		
		if ((w0 > 0) && (w1 > 0))
		begin
			sum0 = rxData[256 + i];
			sum1 = total_weight-sum0;
			mu0 = sum0*1.0/w0;
            mu1 = sum1*1.0/w1;
			sigma_b = (w0*1.0/`imageSize)*(w1*1.0/`imageSize)*(mu0-mu1)*(mu0-mu1);
            if (sigma_b > max_sigma) 
			begin
                max_sigma = sigma_b;
                otsu_threshold = i;
            end
		end
    end
	
	writeAxi(12,otsu_threshold); //set the threshold
	
	file = $fopen("image.bin","rb");  //resend the image
	
	storeImg = 1;
	
    for(i=0;i<`imageSize/4;i=i+1)
    begin
        @(posedge clk);
        #1;
        $fscanf(file,"%c%c%c%c",imgData[7:0],imgData[15:8],imgData[23:16],imgData[31:24]); //32 bit data
        tvalid <= 1'b1;
        sentSize = sentSize + 1;
    end  
    $fclose(file);
    @(posedge clk);
    tvalid <= 1'b0;
	@(posedge intr);
	#100;
	$fclose(file1);
	$stop;
end

initial
begin
	file1 = $fopen("output.bin","wb");  //file to store received img
end

always @(posedge clk)
begin
	if(storeImg & m_axis_data_valid)
		$fwrite(file1,"%c%c%c%c",m_axis_data[7:0],m_axis_data[15:8],m_axis_data[23:16],m_axis_data[31:24]); //32 bit data
end


reg s_axi_awvalid=0;
reg s_axi_wvalid=0;
reg [31:0] s_axi_wdata;
reg [31:0] s_axi_awaddr;
reg s_axi_arvalid=0;
reg [31:0] s_axi_araddr;
wire s_axi_arready;
wire s_axi_rvalid;
wire [31:0] s_axi_rdata;
reg [31:0] axiRdData;
wire s_axi_wready;
 
task writeAxi(
input [31:0] address,
input [31:0] data
);
begin
    @(posedge clk);
    s_axi_awvalid <= 1'b1;
    s_axi_awaddr <= address;
    s_axi_wdata <= data;
    s_axi_wvalid <= 1'b1;
    wait(s_axi_wready);
    @(posedge clk);
    s_axi_awvalid <= 1'b0;
    s_axi_wvalid <= 1'b0;
    @(posedge clk);
end
endtask


task readAxi(
input [31:0] address
);
begin
    @(posedge clk);
    s_axi_arvalid <= 1'b1;
    s_axi_araddr <= address;
    wait(s_axi_arready);
    @(posedge clk);
    s_axi_arvalid <= 1'b0;
    wait(s_axi_rvalid);
    @(posedge clk);
    axiRdData <= s_axi_rdata;
    @(posedge clk);
end
endtask

integer offset = 0;

always @(posedge clk)
begin
    if(m_axis_data_valid)
    begin
        rxData[offset] <= m_axis_data;
        offset <= offset+1;
    end
end
    
otsu_v1_0 otsu
	(
		.s00_axi_aclk(clk),
		.s00_axi_aresetn(aresetn),
		.s00_axi_awaddr(s_axi_awaddr),
		.s00_axi_awprot(),
		.s00_axi_awvalid(s_axi_awvalid),
		.s00_axi_awready(),
		.s00_axi_wdata(s_axi_wdata),
		.s00_axi_wstrb(4'hf),
		.s00_axi_wvalid(s_axi_wvalid),
		.s00_axi_wready(s_axi_wready),
		.s00_axi_bresp(),
		.s00_axi_bvalid(),
		.s00_axi_bready(1'b1),
		.s00_axi_araddr(),
		.s00_axi_arprot(),
		.s00_axi_arvalid(),
		.s00_axi_arready(s_axi_arready),
		.s00_axi_rdata(s_axi_rdata),
		.s00_axi_rresp(),
		.s00_axi_rvalid(s_axi_rvalid),
		.s00_axi_rready(),
		.s_axis_data(imgData),
		.s_axis_data_valid(tvalid),
		.s_axis_keep('hF),
		.s_axis_last(0),
		.s_axis_ready(),
		.m_axis_data(m_axis_data),
		.m_axis_data_valid(m_axis_data_valid),
		.m_axis_keep(),
		.m_axis_last(),
		.m_axis_ready(1'b1),
		.o_intr(intr)
	);    
    
    
endmodule
