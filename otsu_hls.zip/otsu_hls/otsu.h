#include "hls_stream.h"
#include "ap_axi_sdata.h"



typedef ap_axiu<32, 0, 0, 0> axis_t;
