#include "otsu.h"
#include "ap_int.h"


void otsu(hls::stream<axis_t> &inData, hls::stream<axis_t> &outData, unsigned int imageSize,unsigned int threshold, ap_uint<1> &intr){
#pragma HLS INTERFACE mode=ap_none port=intr
#pragma HLS INTERFACE mode=s_axilite port=imageSize
#pragma HLS INTERFACE mode=axis register_mode=both port=outData register
#pragma HLS INTERFACE mode=axis register_mode=both port=inData register
#pragma HLS INTERFACE s_axilite port=return

	unsigned int histogram[256];
	#pragma HLS ARRAY_PARTITION variable=histogram complete

	intr = 0;

	otsu_label0:for(int i = 0; i < 256; i++){
#pragma HLS UNROLL
//#pragma HLS PIPELINE II=1
		histogram[i] = 0;
	}


	//Calculate histogram
	for (unsigned int n = 0; n < imageSize/4; n++) {
	#pragma HLS PIPELINE II=1

		axis_t data = inData.read();

		for (int g = 0; g < 256; g++) {
		#pragma HLS UNROLL
			ap_uint<3> count = 0;
			count = (data.data.range(7, 0) == g) ? 1 : 0;
			count += (data.data.range(15, 8) == g);
			count += (data.data.range(23, 16) == g);
			count += (data.data.range(31, 24) == g);
			histogram[g] += count;
		}
	}

	unsigned int cumHist=0;

	//Send the cumulative histogram
	for(int i = 0; i < 256; i++){
		#pragma HLS PIPELINE II=1
		axis_t data;
		data.data = histogram[i] + cumHist;
		cumHist = cumHist + histogram[i];
		data.keep = 0xF;
		data.last = 0;
		outData.write(data);
	}

	unsigned int WcumHist=0;

	//Send the weighted cumulative histogram
	for(int i = 0; i < 256; i++){
		#pragma HLS PIPELINE II=1
		axis_t data;
		data.data = i*histogram[i] + WcumHist;
		WcumHist = WcumHist + i*histogram[i];
		data.keep = 0xF;
		data.last = (i == 255);
		outData.write(data);
	}

	for (int k = 0; k < 4; k++) {
	#pragma HLS PIPELINE II=1
	    intr = 1;
	}
	intr = 0;

	//Threshold the image
	for (unsigned int n = 0; n < imageSize/4; n++) {
	#pragma HLS PIPELINE II=1

		axis_t data = inData.read();
        axis_t tdata;

		tdata.data.range(7, 0)   = data.data.range(7, 0) >= threshold ? 255 : 0;
		tdata.data.range(15, 8)  = data.data.range(15, 8) >= threshold ? 255 : 0;
		tdata.data.range(23, 16) = data.data.range(23, 16) >= threshold ? 255 : 0;
		tdata.data.range(31, 24) = data.data.range(31, 24) >= threshold ? 255 : 0;

		tdata.keep = 0xF;
		tdata.last = (n == imageSize/4 - 1);
		outData.write(tdata);
	}

	for (int k = 0; k < 4; k++) {
	#pragma HLS PIPELINE II=1
	    intr = 1;
	}
	intr = 0;

}
