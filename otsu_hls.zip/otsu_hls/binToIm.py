import numpy as np
import matplotlib.pyplot as plt
import sys
import os

if len(sys.argv) != 4:
    print("Usage: python raw_to_image.py <filename> <width> <height>")
    print("Example: python raw_to_image.py image.raw 640 480")
    sys.exit(1)

filename = sys.argv[1]
width = int(sys.argv[2])
height = int(sys.argv[3])

# Read raw 8-bit grayscale data
data = np.fromfile(filename, dtype=np.uint8)

expected_size = width * height

if len(data) != expected_size:
    print(f"Error: File contains {len(data)} bytes")
    print(f"Expected {expected_size} bytes for {width} x {height} image")
    sys.exit(1)

# Convert 1D data to 2D image
image = data.reshape((height, width))

# Display image
plt.figure(figsize=(10, 6))
plt.imshow(image, cmap='gray', vmin=0, vmax=255)
plt.axis('off')
plt.title(f"{os.path.basename(filename)} ({width} x {height})")
plt.show()