from PIL import Image
import sys
import numpy as np

if len(sys.argv) != 3:
    print("Usage: python image_to_raw.py <image> <output.raw>")
    print("Example: python image_to_raw.py image.png input.bin")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

# Open image and convert to 8-bit grayscale
image = Image.open(input_file).convert('L')

# Check dimensions
print(f"Image size: {image.width} x {image.height}")

# Convert to NumPy array
data = np.array(image, dtype=np.uint8)

# Write raw 8-bit pixel data
data.tofile(output_file)

print(f"Written {data.size} bytes to {output_file}")